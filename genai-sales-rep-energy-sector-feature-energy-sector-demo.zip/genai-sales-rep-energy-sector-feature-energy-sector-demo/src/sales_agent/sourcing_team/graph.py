import time
from typing import Literal, TypedDict

from langchain_community.tools import TavilySearchResults
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langgraph.constants import END
from langgraph.graph.state import CompiledStateGraph, StateGraph
from langgraph.prebuilt import ToolNode
from langgraph.types import Command, interrupt

from sales_agent.sourcing_team.prompts import sourcing_team_prompt
from sales_agent.config import llm, SLEEP_TIME, HIL_FLAG
from sales_agent.state import SourceState

tools = ['source_team_input', 'reflect_source_team_input', END]


def sourcing_team() -> CompiledStateGraph:
    """Create graph for analyzing market trends and price levels."""
    builder = StateGraph(SourceState)

    builder.add_node(source_team_supervisor)
    builder.add_node(source_team_input)
    builder.add_node(reflect_source_team_input)

    builder.add_edge('__start__', "source_team_supervisor")
    builder.add_edge('source_team_input', "source_team_supervisor")

    return builder.compile()


def source_team_supervisor(
        state: SourceState
) -> Command[Literal[*tools]]:
    """Supervise the market analysis by routing between workers."""
    time.sleep(SLEEP_TIME)

    if state['pricing_advice_asked']:
        return continue_pricing_loop(state)

    class Router(TypedDict):
        """Worker to route to next. If no workers needed, route to FINISH."""
        next: Literal[*tools]

    messages = [{"role": "system", "content": sourcing_team_prompt}, ] + state["messages"]
    response = llm.with_structured_output(Router).invoke(messages)
    goto = response["next"]

    if goto == "FINISH":
        goto = END

    return Command(update={'next': goto}, goto=goto)


def continue_pricing_loop(state: SourceState) -> Command:
    loop_step = state.get('source_loop_step', 0)
    goto = tools[loop_step]

    if loop_step == len(tools) - 1:
        loop_step = 0
    else:
        loop_step += 1

    return Command(update={'next': goto, 'source_loop_step': loop_step}, goto=goto)


def source_team_input(state: SourceState):
    """Review the tool call query."""
    time.sleep(SLEEP_TIME)
    # feedback = interrupt(f'Enter the current raw energy costs and the expected fluctuation in the near future.')
    # return {
    #     'messages': [HumanMessage(content=feedback)]
    # }
    source_input = "Current production cost is €0.0545 per kWh. Expected supply constraints or increased grid congestion could cause temporary price spike of 7%."

    return Command(update={'sourcing_report': source_input, 'messages': [HumanMessage(content=source_input)]}, goto='source_team_supervisor')


# def generate_sourcing_report(state: SourceState) -> Command[Literal['source_team_supervisor']]:
#     """Generate a report on the network team's findings."""
#     time.sleep(SLEEP_TIME)
#     research_question = AIMessage(content="Generate a summary of the findings from the sourcing team regarding the cost of electricity and expected fluctuation.")
#     messages = [research_question]

#     response = llm.invoke(messages)
#     MARKET_REPORT = response.content

#     return Command(update={'sourcing_report': response.content, 'messages': [response]}, goto='source_team_supervisor')


def reflect_source_team_input(state: SourceState) -> Command[Literal['source_team_supervisor', END]]:
    """Reflect on the results of the risk analysis."""
    time.sleep(SLEEP_TIME)
    return Command(update={'messages': [AIMessage(content='The input is correct')]}, goto=END)